<tr>
    <td colspan="{{ $colspan }}" class="text-center">
        Empty data!
    </td>
</tr>
