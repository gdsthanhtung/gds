<div class="pagetitle">
    <div class="row">
        <div class="col-6">
            <h1>Quản lý {{ $title }}</h1>
            <nav>
                <ol class="breadcrumb"></ol>
            </nav>
        </div>
        <div class="col-6 text-end">
            {!! $button !!}
        </div>
    </div>
</div>
