<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">

<title>GDS-QLNT</title>
<meta content="" name="description">
<meta content="" name="keywords">

<!-- Favicons -->
<link href="{{ asset('admin/asset/nice-admin/img/favicon.png') }}" rel="icon">
<link href="{{ asset('admin/asset/nice-admin/img/apple-touch-icon.png') }}" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.gstatic.com" rel="preconnect">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->

<link href="{{ asset('admin/asset/nice-admin/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('admin/asset/nice-admin/vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">
<link href="{{ asset('admin/asset/nice-admin/vendor/boxicons/css/boxicons.min.css') }}" rel="stylesheet">
<link href="{{ asset('admin/asset/nice-admin/vendor/quill/quill.snow.css') }}" rel="stylesheet">
<link href="{{ asset('admin/asset/nice-admin/vendor/quill/quill.bubble.css') }}" rel="stylesheet">
<link href="{{ asset('admin/asset/nice-admin/vendor/remixicon/remixicon.css') }}" rel="stylesheet">
<link href="{{ asset('admin/asset/nice-admin/vendor/simple-datatables/style.css') }}" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="{{ asset('admin/asset/nice-admin/css/style.css') }}" rel="stylesheet">

<link href="{{ asset('admin/css/mycss.css') }}" rel="stylesheet">

<link href="{{ asset('admin/asset/datepicker/css/bootstrap-datepicker.min.css') }}" rel="stylesheet">
<link href="{{ asset('admin/asset/selectpicker/css/bootstrap-multiselect.css') }}" rel="stylesheet">
